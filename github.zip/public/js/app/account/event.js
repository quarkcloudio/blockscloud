// 系统会自动加载本文件
function accountEvent(appObject) {

}