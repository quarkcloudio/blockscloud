function unknown(appObject) {
	layer.msg(lang.unknowFileType,{zIndex: layer.zIndex,success: function(layero){layer.setTop(layero);}});
}