<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use App\Services\Helper;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // $schedule->command('inspire')
        //          ->hourly();
        $schedule->call(function () {
            $config['app_key'] = '24117875';
            $config['app_secret'] = '5472d3e31cd766f3a704907461e62569';
            $signName = '积木云';
            $templateCode = 'SMS_70570267';
            $phone = '15076569631';

            $client = new \GuzzleHttp\Client();
            $res = $client->request('GET', 'http://php.weather.sina.com.cn/xml.php?city=%CA%AF%BC%D2%D7%AF&password=DJOYnieT8234jlsK&day=1');
            $status = $res->getStatusCode();
            if ($status == 200) {
                $obj = simplexml_load_string($res->getBody(),'SimpleXMLElement',LIBXML_NOCDATA);
                $smsParam['name'] = '戴航,明天：'.$obj->Weather->status1.'转'.$obj->Weather->status2;
                Helper::alidayuSendSms($config,$signName,$templateCode,$phone,$smsParam);
            }
        })->dailyAt('20:00');

        $schedule->call(function () {
            $config['app_key'] = '24117875';
            $config['app_secret'] = '5472d3e31cd766f3a704907461e62569';
            $signName = '积木云';
            $templateCode = 'SMS_70450333';
            $phone = '15076569631';

            $client = new \GuzzleHttp\Client();
            $res = $client->request('GET', 'http://php.weather.sina.com.cn/xml.php?city=%CA%AF%BC%D2%D7%AF&password=DJOYnieT8234jlsK&day=1');
            $status = $res->getStatusCode();
            if ($status == 200) {
                $obj = simplexml_load_string($res->getBody(),'SimpleXMLElement',LIBXML_NOCDATA);
                $data = ['笑口常开','开开心心','幸福常在','无忧无虑','心情愉悦','烦恼走开'];
                $smsParam['name'] = '戴航,'.$data[rand(0,5)];
                Helper::alidayuSendSms($config,$signName,$templateCode,$phone,$smsParam);
            }
        })->dailyAt('08:30');
    }

    /**
     * Register the Closure based commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        require base_path('routes/console.php');
    }
}
